<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis version="3.40.9-Bratislava" styleCategories="Symbology|Symbology3D|Labeling|Fields|Forms|Actions|Diagrams|GeometryOptions|Relations|Legend">
  <pipe-data-defined-properties>
    <Option type="Map">
      <Option type="QString" value="" name="name"/>
      <Option name="properties"/>
      <Option type="QString" value="collection" name="type"/>
    </Option>
  </pipe-data-defined-properties>
  <pipe>
    <provider>
      <resampling zoomedInResamplingMethod="nearestNeighbour" enabled="false" zoomedOutResamplingMethod="nearestNeighbour" maxOversampling="2"/>
    </provider>
    <rasterrenderer opacity="1" type="paletted" nodataColor="" alphaBand="-1" band="1">
      <rasterTransparency/>
      <minMaxOrigin>
        <limits>None</limits>
        <extent>WholeRaster</extent>
        <statAccuracy>Estimated</statAccuracy>
        <cumulativeCutLower>0.02</cumulativeCutLower>
        <cumulativeCutUpper>0.98</cumulativeCutUpper>
        <stdDevFactor>2</stdDevFactor>
      </minMaxOrigin>
      <colorPalette>
        <paletteEntry label="0: All non-impervious areas" color="#f0f0f0" value="0" alpha="255"/>
        <paletteEntry label="1: 1% imperviousness" color="#ffedc3" value="1" alpha="255"/>
        <paletteEntry label="2: 2% imperviousness" color="#fde8be" value="2" alpha="255"/>
        <paletteEntry label="3: 3% imperviousness" color="#fbe3ba" value="3" alpha="255"/>
        <paletteEntry label="4: 4% imperviousness" color="#fadeb5" value="4" alpha="255"/>
        <paletteEntry label="5: 5% imperviousness" color="#f8d9b1" value="5" alpha="255"/>
        <paletteEntry label="6: 6% imperviousness" color="#f6d5ac" value="6" alpha="255"/>
        <paletteEntry label="7: 7% imperviousness" color="#f4d0a8" value="7" alpha="255"/>
        <paletteEntry label="8: 8% imperviousness" color="#f2cba4" value="8" alpha="255"/>
        <paletteEntry label="9: 9% imperviousness" color="#f1c7a0" value="9" alpha="255"/>
        <paletteEntry label="10: 10% imperviousness" color="#efc29c" value="10" alpha="255"/>
        <paletteEntry label="11: 11% imperviousness" color="#edbe98" value="11" alpha="255"/>
        <paletteEntry label="12: 12% imperviousness" color="#ebba94" value="12" alpha="255"/>
        <paletteEntry label="13: 13% imperviousness" color="#eab690" value="13" alpha="255"/>
        <paletteEntry label="14: 14% imperviousness" color="#e8b28d" value="14" alpha="255"/>
        <paletteEntry label="15: 15% imperviousness" color="#e6ae89" value="15" alpha="255"/>
        <paletteEntry label="16: 16% imperviousness" color="#e4aa86" value="16" alpha="255"/>
        <paletteEntry label="17: 17% imperviousness" color="#e3a682" value="17" alpha="255"/>
        <paletteEntry label="18: 18% imperviousness" color="#e1a27f" value="18" alpha="255"/>
        <paletteEntry label="19: 19% imperviousness" color="#df9e7b" value="19" alpha="255"/>
        <paletteEntry label="20: 20% imperviousness" color="#de9b78" value="20" alpha="255"/>
        <paletteEntry label="21: 21% imperviousness" color="#dc9775" value="21" alpha="255"/>
        <paletteEntry label="22: 22% imperviousness" color="#da9472" value="22" alpha="255"/>
        <paletteEntry label="23: 23% imperviousness" color="#d9906f" value="23" alpha="255"/>
        <paletteEntry label="24: 24% imperviousness" color="#d78d6c" value="24" alpha="255"/>
        <paletteEntry label="25: 25% imperviousness" color="#d58a69" value="25" alpha="255"/>
        <paletteEntry label="26: 26% imperviousness" color="#d48766" value="26" alpha="255"/>
        <paletteEntry label="27: 27% imperviousness" color="#d28464" value="27" alpha="255"/>
        <paletteEntry label="28: 28% imperviousness" color="#d18061" value="28" alpha="255"/>
        <paletteEntry label="29: 29% imperviousness" color="#cf7d5e" value="29" alpha="255"/>
        <paletteEntry label="30: 30% imperviousness" color="#cd7a5c" value="30" alpha="255"/>
        <paletteEntry label="31: 31% imperviousness" color="#cc7859" value="31" alpha="255"/>
        <paletteEntry label="32: 32% imperviousness" color="#ca7557" value="32" alpha="255"/>
        <paletteEntry label="33: 33% imperviousness" color="#c97254" value="33" alpha="255"/>
        <paletteEntry label="34: 34% imperviousness" color="#c76f52" value="34" alpha="255"/>
        <paletteEntry label="35: 35% imperviousness" color="#c66d50" value="35" alpha="255"/>
        <paletteEntry label="36: 36% imperviousness" color="#c46a4e" value="36" alpha="255"/>
        <paletteEntry label="37: 37% imperviousness" color="#c2674b" value="37" alpha="255"/>
        <paletteEntry label="38: 38% imperviousness" color="#c16549" value="38" alpha="255"/>
        <paletteEntry label="39: 39% imperviousness" color="#bf6247" value="39" alpha="255"/>
        <paletteEntry label="40: 40% imperviousness" color="#be6045" value="40" alpha="255"/>
        <paletteEntry label="41: 41% imperviousness" color="#bc5e43" value="41" alpha="255"/>
        <paletteEntry label="42: 42% imperviousness" color="#bb5b41" value="42" alpha="255"/>
        <paletteEntry label="43: 43% imperviousness" color="#b9593f" value="43" alpha="255"/>
        <paletteEntry label="44: 44% imperviousness" color="#b8573d" value="44" alpha="255"/>
        <paletteEntry label="45: 45% imperviousness" color="#b6543b" value="45" alpha="255"/>
        <paletteEntry label="46: 46% imperviousness" color="#b5523a" value="46" alpha="255"/>
        <paletteEntry label="47: 47% imperviousness" color="#b45038" value="47" alpha="255"/>
        <paletteEntry label="48: 48% imperviousness" color="#b24e36" value="48" alpha="255"/>
        <paletteEntry label="49: 49% imperviousness" color="#b14c34" value="49" alpha="255"/>
        <paletteEntry label="50: 50% imperviousness" color="#af4a33" value="50" alpha="255"/>
        <paletteEntry label="51: 51% imperviousness" color="#ae4831" value="51" alpha="255"/>
        <paletteEntry label="52: 52% imperviousness" color="#ac4630" value="52" alpha="255"/>
        <paletteEntry label="53: 53% imperviousness" color="#ab442e" value="53" alpha="255"/>
        <paletteEntry label="54: 54% imperviousness" color="#aa432d" value="54" alpha="255"/>
        <paletteEntry label="55: 55% imperviousness" color="#a8412b" value="55" alpha="255"/>
        <paletteEntry label="56: 56% imperviousness" color="#a73f2a" value="56" alpha="255"/>
        <paletteEntry label="57: 57% imperviousness" color="#a53d28" value="57" alpha="255"/>
        <paletteEntry label="58: 58% imperviousness" color="#a43b27" value="58" alpha="255"/>
        <paletteEntry label="59: 59% imperviousness" color="#a33a25" value="59" alpha="255"/>
        <paletteEntry label="60: 60% imperviousness" color="#a13824" value="60" alpha="255"/>
        <paletteEntry label="61: 61% imperviousness" color="#a03723" value="61" alpha="255"/>
        <paletteEntry label="62: 62% imperviousness" color="#9f3522" value="62" alpha="255"/>
        <paletteEntry label="63: 63% imperviousness" color="#9d3320" value="63" alpha="255"/>
        <paletteEntry label="64: 64% imperviousness" color="#9c321f" value="64" alpha="255"/>
        <paletteEntry label="65: 65% imperviousness" color="#9b301e" value="65" alpha="255"/>
        <paletteEntry label="66: 66% imperviousness" color="#992f1d" value="66" alpha="255"/>
        <paletteEntry label="67: 67% imperviousness" color="#982e1c" value="67" alpha="255"/>
        <paletteEntry label="68: 68% imperviousness" color="#972c1b" value="68" alpha="255"/>
        <paletteEntry label="69: 69% imperviousness" color="#952b1a" value="69" alpha="255"/>
        <paletteEntry label="70: 70% imperviousness" color="#942a18" value="70" alpha="255"/>
        <paletteEntry label="71: 71% imperviousness" color="#932817" value="71" alpha="255"/>
        <paletteEntry label="72: 72% imperviousness" color="#922716" value="72" alpha="255"/>
        <paletteEntry label="73: 73% imperviousness" color="#902615" value="73" alpha="255"/>
        <paletteEntry label="74: 74% imperviousness" color="#8f2414" value="74" alpha="255"/>
        <paletteEntry label="75: 75% imperviousness" color="#8e2313" value="75" alpha="255"/>
        <paletteEntry label="76: 76% imperviousness" color="#8d2213" value="76" alpha="255"/>
        <paletteEntry label="77: 77% imperviousness" color="#8b2112" value="77" alpha="255"/>
        <paletteEntry label="78: 78% imperviousness" color="#8a2011" value="78" alpha="255"/>
        <paletteEntry label="79: 79% imperviousness" color="#891f10" value="79" alpha="255"/>
        <paletteEntry label="80: 80% imperviousness" color="#881d0f" value="80" alpha="255"/>
        <paletteEntry label="81: 81% imperviousness" color="#861c0e" value="81" alpha="255"/>
        <paletteEntry label="82: 82% imperviousness" color="#851b0d" value="82" alpha="255"/>
        <paletteEntry label="83: 83% imperviousness" color="#841a0d" value="83" alpha="255"/>
        <paletteEntry label="84: 84% imperviousness" color="#83190c" value="84" alpha="255"/>
        <paletteEntry label="85: 85% imperviousness" color="#82180b" value="85" alpha="255"/>
        <paletteEntry label="86: 86% imperviousness" color="#80170a" value="86" alpha="255"/>
        <paletteEntry label="87: 87% imperviousness" color="#7f160a" value="87" alpha="255"/>
        <paletteEntry label="88: 88% imperviousness" color="#7e1509" value="88" alpha="255"/>
        <paletteEntry label="89: 89% imperviousness" color="#7d1508" value="89" alpha="255"/>
        <paletteEntry label="90: 90% imperviousness" color="#7c1408" value="90" alpha="255"/>
        <paletteEntry label="91: 91% imperviousness" color="#7b1307" value="91" alpha="255"/>
        <paletteEntry label="92: 92% imperviousness" color="#791206" value="92" alpha="255"/>
        <paletteEntry label="93: 93% imperviousness" color="#781106" value="93" alpha="255"/>
        <paletteEntry label="94: 94% imperviousness" color="#771005" value="94" alpha="255"/>
        <paletteEntry label="95: 95% imperviousness" color="#760f04" value="95" alpha="255"/>
        <paletteEntry label="96: 96% imperviousness" color="#750f04" value="96" alpha="255"/>
        <paletteEntry label="97: 97% imperviousness" color="#740e03" value="97" alpha="255"/>
        <paletteEntry label="98: 98% imperviousness" color="#730d03" value="98" alpha="255"/>
        <paletteEntry label="99: 99% imperviousness" color="#720c02" value="99" alpha="255"/>
        <paletteEntry label="100: 100% imperviousness" color="#710c02" value="100" alpha="255"/>
        <paletteEntry label="255: Outside area" color="#000000" value="255" alpha="255"/>
      </colorPalette>
      <colorramp type="randomcolors" name="[source]">
        <Option/>
      </colorramp>
    </rasterrenderer>
    <brightnesscontrast gamma="1" brightness="0" contrast="0"/>
    <huesaturation colorizeGreen="128" grayscaleMode="0" invertColors="0" colorizeRed="255" colorizeStrength="100" colorizeBlue="128" saturation="0" colorizeOn="0"/>
    <rasterresampler maxOversampling="2"/>
    <resamplingStage>resamplingFilter</resamplingStage>
  </pipe>
  <blendMode>0</blendMode>
</qgis>
