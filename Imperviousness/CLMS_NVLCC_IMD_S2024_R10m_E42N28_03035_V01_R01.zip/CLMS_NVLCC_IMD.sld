<?xml version="1.0" encoding="UTF-8"?>
<StyledLayerDescriptor xmlns="http://www.opengis.net/sld" version="1.0.0" xmlns:gml="http://www.opengis.net/gml" xmlns:ogc="http://www.opengis.net/ogc" xmlns:sld="http://www.opengis.net/sld">
  <UserLayer>
    <sld:LayerFeatureConstraints>
      <sld:FeatureTypeConstraint/>
    </sld:LayerFeatureConstraints>
    <sld:UserStyle>
      <sld:Name>CLMS_NVLCC_IMD</sld:Name>
      <sld:FeatureTypeStyle>
        <sld:Rule>
          <sld:RasterSymbolizer>
            <sld:ChannelSelection>
              <sld:GrayChannel>
                <sld:SourceChannelName>1</sld:SourceChannelName>
              </sld:GrayChannel>
            </sld:ChannelSelection>
            <sld:ColorMap type="values">
              <sld:ColorMapEntry label="0: All non-impervious areas" color="#f0f0f0" quantity="0"/>
              <sld:ColorMapEntry label="1: 1% imperviousness" color="#ffedc3" quantity="1"/>
              <sld:ColorMapEntry label="2: 2% imperviousness" color="#fde8be" quantity="2"/>
              <sld:ColorMapEntry label="3: 3% imperviousness" color="#fbe3ba" quantity="3"/>
              <sld:ColorMapEntry label="4: 4% imperviousness" color="#fadeb5" quantity="4"/>
              <sld:ColorMapEntry label="5: 5% imperviousness" color="#f8d9b1" quantity="5"/>
              <sld:ColorMapEntry label="6: 6% imperviousness" color="#f6d5ac" quantity="6"/>
              <sld:ColorMapEntry label="7: 7% imperviousness" color="#f4d0a8" quantity="7"/>
              <sld:ColorMapEntry label="8: 8% imperviousness" color="#f2cba4" quantity="8"/>
              <sld:ColorMapEntry label="9: 9% imperviousness" color="#f1c7a0" quantity="9"/>
              <sld:ColorMapEntry label="10: 10% imperviousness" color="#efc29c" quantity="10"/>
              <sld:ColorMapEntry label="11: 11% imperviousness" color="#edbe98" quantity="11"/>
              <sld:ColorMapEntry label="12: 12% imperviousness" color="#ebba94" quantity="12"/>
              <sld:ColorMapEntry label="13: 13% imperviousness" color="#eab690" quantity="13"/>
              <sld:ColorMapEntry label="14: 14% imperviousness" color="#e8b28d" quantity="14"/>
              <sld:ColorMapEntry label="15: 15% imperviousness" color="#e6ae89" quantity="15"/>
              <sld:ColorMapEntry label="16: 16% imperviousness" color="#e4aa86" quantity="16"/>
              <sld:ColorMapEntry label="17: 17% imperviousness" color="#e3a682" quantity="17"/>
              <sld:ColorMapEntry label="18: 18% imperviousness" color="#e1a27f" quantity="18"/>
              <sld:ColorMapEntry label="19: 19% imperviousness" color="#df9e7b" quantity="19"/>
              <sld:ColorMapEntry label="20: 20% imperviousness" color="#de9b78" quantity="20"/>
              <sld:ColorMapEntry label="21: 21% imperviousness" color="#dc9775" quantity="21"/>
              <sld:ColorMapEntry label="22: 22% imperviousness" color="#da9472" quantity="22"/>
              <sld:ColorMapEntry label="23: 23% imperviousness" color="#d9906f" quantity="23"/>
              <sld:ColorMapEntry label="24: 24% imperviousness" color="#d78d6c" quantity="24"/>
              <sld:ColorMapEntry label="25: 25% imperviousness" color="#d58a69" quantity="25"/>
              <sld:ColorMapEntry label="26: 26% imperviousness" color="#d48766" quantity="26"/>
              <sld:ColorMapEntry label="27: 27% imperviousness" color="#d28464" quantity="27"/>
              <sld:ColorMapEntry label="28: 28% imperviousness" color="#d18061" quantity="28"/>
              <sld:ColorMapEntry label="29: 29% imperviousness" color="#cf7d5e" quantity="29"/>
              <sld:ColorMapEntry label="30: 30% imperviousness" color="#cd7a5c" quantity="30"/>
              <sld:ColorMapEntry label="31: 31% imperviousness" color="#cc7859" quantity="31"/>
              <sld:ColorMapEntry label="32: 32% imperviousness" color="#ca7557" quantity="32"/>
              <sld:ColorMapEntry label="33: 33% imperviousness" color="#c97254" quantity="33"/>
              <sld:ColorMapEntry label="34: 34% imperviousness" color="#c76f52" quantity="34"/>
              <sld:ColorMapEntry label="35: 35% imperviousness" color="#c66d50" quantity="35"/>
              <sld:ColorMapEntry label="36: 36% imperviousness" color="#c46a4e" quantity="36"/>
              <sld:ColorMapEntry label="37: 37% imperviousness" color="#c2674b" quantity="37"/>
              <sld:ColorMapEntry label="38: 38% imperviousness" color="#c16549" quantity="38"/>
              <sld:ColorMapEntry label="39: 39% imperviousness" color="#bf6247" quantity="39"/>
              <sld:ColorMapEntry label="40: 40% imperviousness" color="#be6045" quantity="40"/>
              <sld:ColorMapEntry label="41: 41% imperviousness" color="#bc5e43" quantity="41"/>
              <sld:ColorMapEntry label="42: 42% imperviousness" color="#bb5b41" quantity="42"/>
              <sld:ColorMapEntry label="43: 43% imperviousness" color="#b9593f" quantity="43"/>
              <sld:ColorMapEntry label="44: 44% imperviousness" color="#b8573d" quantity="44"/>
              <sld:ColorMapEntry label="45: 45% imperviousness" color="#b6543b" quantity="45"/>
              <sld:ColorMapEntry label="46: 46% imperviousness" color="#b5523a" quantity="46"/>
              <sld:ColorMapEntry label="47: 47% imperviousness" color="#b45038" quantity="47"/>
              <sld:ColorMapEntry label="48: 48% imperviousness" color="#b24e36" quantity="48"/>
              <sld:ColorMapEntry label="49: 49% imperviousness" color="#b14c34" quantity="49"/>
              <sld:ColorMapEntry label="50: 50% imperviousness" color="#af4a33" quantity="50"/>
              <sld:ColorMapEntry label="51: 51% imperviousness" color="#ae4831" quantity="51"/>
              <sld:ColorMapEntry label="52: 52% imperviousness" color="#ac4630" quantity="52"/>
              <sld:ColorMapEntry label="53: 53% imperviousness" color="#ab442e" quantity="53"/>
              <sld:ColorMapEntry label="54: 54% imperviousness" color="#aa432d" quantity="54"/>
              <sld:ColorMapEntry label="55: 55% imperviousness" color="#a8412b" quantity="55"/>
              <sld:ColorMapEntry label="56: 56% imperviousness" color="#a73f2a" quantity="56"/>
              <sld:ColorMapEntry label="57: 57% imperviousness" color="#a53d28" quantity="57"/>
              <sld:ColorMapEntry label="58: 58% imperviousness" color="#a43b27" quantity="58"/>
              <sld:ColorMapEntry label="59: 59% imperviousness" color="#a33a25" quantity="59"/>
              <sld:ColorMapEntry label="60: 60% imperviousness" color="#a13824" quantity="60"/>
              <sld:ColorMapEntry label="61: 61% imperviousness" color="#a03723" quantity="61"/>
              <sld:ColorMapEntry label="62: 62% imperviousness" color="#9f3522" quantity="62"/>
              <sld:ColorMapEntry label="63: 63% imperviousness" color="#9d3320" quantity="63"/>
              <sld:ColorMapEntry label="64: 64% imperviousness" color="#9c321f" quantity="64"/>
              <sld:ColorMapEntry label="65: 65% imperviousness" color="#9b301e" quantity="65"/>
              <sld:ColorMapEntry label="66: 66% imperviousness" color="#992f1d" quantity="66"/>
              <sld:ColorMapEntry label="67: 67% imperviousness" color="#982e1c" quantity="67"/>
              <sld:ColorMapEntry label="68: 68% imperviousness" color="#972c1b" quantity="68"/>
              <sld:ColorMapEntry label="69: 69% imperviousness" color="#952b1a" quantity="69"/>
              <sld:ColorMapEntry label="70: 70% imperviousness" color="#942a18" quantity="70"/>
              <sld:ColorMapEntry label="71: 71% imperviousness" color="#932817" quantity="71"/>
              <sld:ColorMapEntry label="72: 72% imperviousness" color="#922716" quantity="72"/>
              <sld:ColorMapEntry label="73: 73% imperviousness" color="#902615" quantity="73"/>
              <sld:ColorMapEntry label="74: 74% imperviousness" color="#8f2414" quantity="74"/>
              <sld:ColorMapEntry label="75: 75% imperviousness" color="#8e2313" quantity="75"/>
              <sld:ColorMapEntry label="76: 76% imperviousness" color="#8d2213" quantity="76"/>
              <sld:ColorMapEntry label="77: 77% imperviousness" color="#8b2112" quantity="77"/>
              <sld:ColorMapEntry label="78: 78% imperviousness" color="#8a2011" quantity="78"/>
              <sld:ColorMapEntry label="79: 79% imperviousness" color="#891f10" quantity="79"/>
              <sld:ColorMapEntry label="80: 80% imperviousness" color="#881d0f" quantity="80"/>
              <sld:ColorMapEntry label="81: 81% imperviousness" color="#861c0e" quantity="81"/>
              <sld:ColorMapEntry label="82: 82% imperviousness" color="#851b0d" quantity="82"/>
              <sld:ColorMapEntry label="83: 83% imperviousness" color="#841a0d" quantity="83"/>
              <sld:ColorMapEntry label="84: 84% imperviousness" color="#83190c" quantity="84"/>
              <sld:ColorMapEntry label="85: 85% imperviousness" color="#82180b" quantity="85"/>
              <sld:ColorMapEntry label="86: 86% imperviousness" color="#80170a" quantity="86"/>
              <sld:ColorMapEntry label="87: 87% imperviousness" color="#7f160a" quantity="87"/>
              <sld:ColorMapEntry label="88: 88% imperviousness" color="#7e1509" quantity="88"/>
              <sld:ColorMapEntry label="89: 89% imperviousness" color="#7d1508" quantity="89"/>
              <sld:ColorMapEntry label="90: 90% imperviousness" color="#7c1408" quantity="90"/>
              <sld:ColorMapEntry label="91: 91% imperviousness" color="#7b1307" quantity="91"/>
              <sld:ColorMapEntry label="92: 92% imperviousness" color="#791206" quantity="92"/>
              <sld:ColorMapEntry label="93: 93% imperviousness" color="#781106" quantity="93"/>
              <sld:ColorMapEntry label="94: 94% imperviousness" color="#771005" quantity="94"/>
              <sld:ColorMapEntry label="95: 95% imperviousness" color="#760f04" quantity="95"/>
              <sld:ColorMapEntry label="96: 96% imperviousness" color="#750f04" quantity="96"/>
              <sld:ColorMapEntry label="97: 97% imperviousness" color="#740e03" quantity="97"/>
              <sld:ColorMapEntry label="98: 98% imperviousness" color="#730d03" quantity="98"/>
              <sld:ColorMapEntry label="99: 99% imperviousness" color="#720c02" quantity="99"/>
              <sld:ColorMapEntry label="100: 100% imperviousness" color="#710c02" quantity="100"/>
              <sld:ColorMapEntry label="255: Outside area" color="#000000" quantity="255"/>
            </sld:ColorMap>
          </sld:RasterSymbolizer>
        </sld:Rule>
      </sld:FeatureTypeStyle>
    </sld:UserStyle>
  </UserLayer>
</StyledLayerDescriptor>
